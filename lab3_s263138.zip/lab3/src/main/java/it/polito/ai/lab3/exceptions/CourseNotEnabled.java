package it.polito.ai.lab3.exceptions;

public class CourseNotEnabled  extends TeamServiceException{
}
