package it.polito.ai.lab3.exceptions;

public class TokenNotFoundException  extends TeamServiceException  {
}
