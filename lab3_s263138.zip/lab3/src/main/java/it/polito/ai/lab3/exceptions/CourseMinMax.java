package it.polito.ai.lab3.exceptions;

public class CourseMinMax extends TeamServiceException {
}
