package it.polito.ai.lab2.exceptions;

public class CourseMinMax extends TeamServiceException {
}
