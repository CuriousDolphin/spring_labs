package it.polito.ai.lab2.exceptions;

public class StudentDuplicate extends TeamServiceException {
}
