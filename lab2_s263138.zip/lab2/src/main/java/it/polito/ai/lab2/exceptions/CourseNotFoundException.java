package it.polito.ai.lab2.exceptions;

public class CourseNotFoundException extends TeamServiceException {
}
